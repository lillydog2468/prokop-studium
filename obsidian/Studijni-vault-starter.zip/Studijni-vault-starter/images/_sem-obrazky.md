Sem ukládej obrázky (Obsidian je sem může dávat automaticky – viz README).
