# 🦴 Studijní vault – startovací balíček

Ahoj! Tohle je hotová kostra Obsidianu pro studium fyzioterapie. Stačí rozbalit a otevřít.

## 1. Jak to otevřít
1. Nainstaluj Obsidian zdarma z **obsidian.md**.
2. Rozbal tenhle ZIP (na iPhone/iPad sync přes iCloud viz níže).
3. V Obsidianu dej **Open folder as vault** (Otevřít složku jako trezor) a vyber složku `Studijni-vault-starter`.
4. Složku si klidně přejmenuj (např. „Studium“).

**iPhone/iPad + Mac:** složku dej do *iCloud Drive → Obsidian* (ta s ikonkou Obsidianu). Na iPhonu pak v Obsidianu otevři trezor odtamtud.
**Windows:** iCloud na Windows podle oficiální nápovědy může dělat duplicity – spolehlivější je placený Obsidian Sync, nebo si sync řeš jinak (viz web).

## 2. Struktura složek
| Složka | Na co |
|---|---|
| `00 Inbox` | rychlé nápady, nové poznámky (sem padají automaticky) |
| `01 Atlas/Šablony` | šablony – nesahej, jen používej |
| `02 Studium/Fyzioterapie/<předmět>` | poznámky z přednášek, podsložky `Zdroje`, `Pojmy` |
| `02 Studium/Zkoušky` | jedna poznámka = jedna zkouška/zápočet |
| `02 Studium/Týdenní review` | týdenní ohlédnutí za studiem |
| `02 Studium/materialy` | PDF, prezentace |
| `images` | obrázky (vkládají se sem automaticky) |

Nový předmět = nová složka v `02 Studium/Fyzioterapie` (šablony ji samy nabídnou).

## 3. Šablony
| Šablona | K čemu |
|---|---|
| Studijní poznámka (přednáška) | výpisky z přednášky: téma, výpisky, pojmy, otázky, Anki kartičky |
| Zkouška | plán opakování T-14 / T-7 / T-3 / T-1 a přehled přednášek z předmětu |
| Internetové zdroje | výpisky z článku, videa, webu |
| Týdenní review (studijní) | 15 minut v neděli: co se povedlo, zkoušky na obzoru, top 3 |

Šablony používají plugin **Templater** (kód `<% … %>`). Bez něj se vloží jako text.
Nastavení: Settings → Templater → *Template folder location* = `01 Atlas/Šablony`.
Pak nová poznámka → příkaz **Templater: Create new note from template**.

Základní (vestavěné) šablony už mají složku nastavenou na `01 Atlas/Šablony`.

## 4. Doporučené pluginy (nainstaluj si sám)
Settings → Community plugins → **Turn on community plugins** → **Browse**, vyhledej a dej Install + Enable:

- **Templater** – dynamické šablony (nutné pro šablony výše)
- **Dataview** – dotazy nad poznámkami (seznamy přednášek, zkoušek v šablonách)
- **Full Calendar** – zkoušky v kalendáři
- **Calendar** – kalendář v postranním panelu pro denní poznámky
- **Excalidraw** – kreslení schémat (svaly, klouby…)
- **Kanban** – nástěnky úkolů v Markdownu
- **Checklist** – všechny checklisty z poznámek v jednom přehledu
- **Tag Wrangler** – přejmenování a slučování tagů
- **Iconize** – ikonky ke složkám a souborům
- **Attachment Management** – vlastní cesty a přejmenování příloh
- **Editing Toolbar** – panel nástrojů jako ve Wordu
- **Excel** – tabulky vložené do poznámek
- **Book Search** – poznámky ke knihám s údaji z Google Books
- **Clipper** – ukládání zvýrazněných pasáží z webu

## 5. Propojování poznámek
- `[[Název poznámky]]` = odkaz. Když poznámka neexistuje, kliknutím ji vytvoříš.
- `![[obrazek.png]]` nebo `![[skripta.pdf]]` = vložení souboru.
- `#tag` = štítek. Vpravo uvidíš **Backlinks** (kdo odkazuje sem).
- Zkus otevřít **Graph view** – uvidíš, jak spolu poznámky souvisí.

Ukázky: `Svaly krku`, `Retrakce a protrakce`, `Latina – 1. deklinace` (klidně smaž).

Soubory `_sem-…md` jsou jen popisky složek – můžeš je smazat.
