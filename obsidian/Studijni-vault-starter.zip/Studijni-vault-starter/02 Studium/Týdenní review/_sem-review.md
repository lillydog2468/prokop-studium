Sem se ukládají týdenní review ze šablony.
