Sem dávej PDF, prezentace a další soubory k předmětům.
