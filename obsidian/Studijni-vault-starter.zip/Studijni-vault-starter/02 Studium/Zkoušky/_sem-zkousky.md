Sem se automaticky ukládají poznámky ze šablony Zkouška.
