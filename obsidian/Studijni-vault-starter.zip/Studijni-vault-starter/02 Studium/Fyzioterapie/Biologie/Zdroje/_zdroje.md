Sem si dej zdroje k biologii.
