Sem si dávej slovíčka k jednotlivým lekcím (např. „01 Lekce – slovíčka“).
