---
typ: prednaska
predmet: Latina
tags: [latina, deklinace]
stav: projdeno
---
# 🏛️ Latina – 1. deklinace (vzor *vena*)

## 🎯 Hlavní téma
Podstatná jména zakončená v 1. pádě na **-a**, ve 2. pádě na **-ae**. Většinou ženského rodu.

## 📝 Výpisky
| Pád | Singulár | Plurál |
|---|---|---|
| Nom. (1.) | ven**a** | ven**ae** |
| Gen. (2.) | ven**ae** | ven**arum** |
| Acc. (4.) | ven**am** | ven**as** |
| Abl. (7.) | ven**a** | ven**is** |

## 🔑 Klíčové pojmy
| Latinsky | Česky |
| ----- | ---------- |
| vena, -ae f. | žíla |
| costa, -ae f. | žebro |
| scapula, -ae f. | lopatka |
| fossa, -ae f. | jáma |

## 🃏 Anki kartičky
Gen. sg. slova *costa* je {costae}. #card
Nom. pl. slova *vena* je {venae}. #card

## 🔗 Souvisí
- [[Svaly krku]] – *fossa*, *costa* uvidíš v anatomii všude
