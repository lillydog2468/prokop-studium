Sem si dej zdroje (prezentace, skripta) k anatomii.
