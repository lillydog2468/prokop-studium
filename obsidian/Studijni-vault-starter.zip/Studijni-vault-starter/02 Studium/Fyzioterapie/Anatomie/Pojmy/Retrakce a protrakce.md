---
tags: [pojem, anatomie]
---
# Retrakce a protrakce
- **Protrakce** = posun dopředu (např. lopatky od páteře, mandibula dopředu).
- **Retrakce** = posun dozadu (lopatky k páteři, mandibula dozadu).
- Jsou to opačné pohyby – u lopatek ovlivňují postavení ramen.

Použito v: [[Svaly krku]]
