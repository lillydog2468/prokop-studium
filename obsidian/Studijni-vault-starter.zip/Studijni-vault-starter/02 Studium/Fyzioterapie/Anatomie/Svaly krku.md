---
typ: prednaska
predmet: Anatomie
datum: 2026-10-23
tags: [prednaska, anatomie, svaly]
stav: rozpracováno
---
# 📚 Svaly krku

## 🎯 Hlavní téma
Svaly krku: povrchové, nadjazylkové a podjazylkové, skalenové, prevertebrální a subokcipitální. Na konci krční fascie.

## 📝 Výpisky
| Sval | Začátek | Úpon | Funkce | Inervace |
|---|---|---|---|---|
| m. sternocleidomastoideus | sternum + klavikula (2 hlavy) | proc. mastoideus, linea nuchae sup. | jednostr. rotace na opačnou + úklon na stejnou | n. XI + C2–C3 |
| mm. scaleni (ant., med., post.) | proc. transversi C2–C7 | 1. a 2. žebro | úklon krku, pomocné nádechové svaly | rr. ventrales C3–C8 |
| m. longus colli | těla Th1–Th3 | krční obratle, atlas | flexe hlavy a krku | rr. ventrales C1–C8 |
| m. rectus capitis posterior major | proc. spinosus C2 | linea nuchae inf. | záklon, rotace na stejnou stranu | n. suboccipitalis |

> [!tip] Klinika
> Mezi m. scalenus anterior a medius prochází **a. subclavia** a **plexus brachialis** → při útlaku *skalenový syndrom*.

## 🔑 Klíčové pojmy
| Pojem | Vysvětlení |
| ----- | ---------- |
| [[Retrakce a protrakce]] | pohyb dozadu / dopředu |
| fascia colli | krční fascie (3 listy) |

## ❓ Otázky / co nechápu
- [x] Kudy přesně vede fissura scalenorum?
- [ ] Rozdíl mezi m. longus colli a m. longus capitis

## 🔗 Zdroje
- prezentace z přednášky → dej PDF do `02 Studium/materialy` a vlož sem `![[nazev.pdf]]`
