<%*
const tyden = tp.date.now("GGGG-[W]WW");
const slozka = "02 Studium/Týdenní review";
let cil = slozka + "/Týden " + tyden;
let n = 2;
while (app.vault.getAbstractFileByPath(cil + ".md")) {
  cil = slozka + "/Týden " + tyden + " (" + n + ")";
  n++;
}
if (n > 2) new Notice("Review pro tento týden už existuje, zakládám další: " + cil.split("/").pop());
await tp.file.move(cil);
-%>
---
typ: tydenni_review
tyden: <% tyden %>
datum: <% tp.date.now("YYYY-MM-DD") %>
---
> [!info] Jak na to
> Na konci týdne (třeba v neděli) projdi sekce, buď upřímný a na konci si vyber 3 hlavní věci na příští týden. Stačí 15 minut.

# 🗓️ Týden <% tyden %>

## ✅ Co se povedlo
- <% tp.file.cursor(1) %>

## ❌ Co nevyšlo a proč
- 

## 📚 Škola
**Kolik jsem toho prošel:** (přednášky, kartičky, cvičení)
- 

**Zkoušky v příštích 14 dnech:**
```dataview
LIST druh + " · " + predmet + " · " + datum
WHERE typ = "zkouska" AND date(datum) >= date(today) AND date(datum) <= date(today) + dur(14 days)
SORT datum ASC
```

**Přednášky zapsané tento týden:**
```dataview
LIST predmet
FROM "02 Studium"
WHERE typ = "prednaska" AND file.cday >= date(today) - dur(7 days)
SORT file.cday ASC
```

## 🔜 Top 3 na příští týden
1. 
2. 
3. 

## 💡 Co si z týdne odnáším (studijně)
> 
