<%*
let nazev = tp.file.title;
if (/^(Untitled|Bez názvu)/i.test(nazev)) {
  const zadano = await tp.system.prompt("Název přednášky");
  if (zadano && zadano.trim()) {
    nazev = zadano.trim();
    await tp.file.rename(nazev);
  }
}
const zakladCesta = "02 Studium/Fyzioterapie";
const zaklad = app.vault.getAbstractFileByPath(zakladCesta);
const predmety = (zaklad && zaklad.children ? zaklad.children : [])
  .filter(f => f.children)
  .map(f => f.name)
  .sort((a, b) => a.localeCompare(b, "cs"));
const jiny = "✏️ Jiný předmět…";
let predmet = await tp.system.suggester([...predmety, jiny], [...predmety, jiny], false, "Předmět přednášky");
if (!predmet || predmet === jiny) {
  predmet = (await tp.system.prompt("Název předmětu")) || "";
}
let zdroj = "";
const slozkaZdroju = app.vault.getAbstractFileByPath(zakladCesta + "/" + predmet + "/Zdroje");
if (predmet && slozkaZdroju && slozkaZdroju.children) {
  const zdroje = slozkaZdroju.children
    .filter(f => f.extension === "md")
    .map(f => f.basename)
    .sort((a, b) => a.localeCompare(b, "cs"));
  const zadny = "žádný";
  const vybrany = await tp.system.suggester([zadny, ...zdroje], [zadny, ...zdroje], false, "Zdrojová poznámka (Zdroje)");
  if (vybrany && vybrany !== zadny) zdroj = vybrany;
}
const deck = predmet ? "Fyzioterapie::" + predmet : "Fyzioterapie";
-%>
---
typ: prednaska
predmet: <% predmet %>
datum: <% tp.date.now("YYYY-MM-DD") %>
zdroj: <% zdroj ? '"[[' + zdroj + ']]"' : '' %>
tags: [prednaska]
stav: neprojdeno
---
# 📚 <% nazev %>

## 🎯 Hlavní téma
<% tp.file.cursor(1) %>

## 📝 Výpisky
- 

## 🔑 Klíčové pojmy
| Pojem | Vysvětlení |
| ----- | ---------- |
|       |            |

## ❓ Otázky / co nechápu
- [ ] 

## 🃏 Anki kartičky
TARGET DECK: <% deck %>

<!-- Jedna doplňovačka na řádek, skrytou část dej do složených závorek a na konec #card. Příklad: Biceps brachii inervuje nervus {musculocutaneus}. #card -->


## 🔗 Zdroje
- <% zdroj ? "[[" + zdroj + "]]" : "" %>
