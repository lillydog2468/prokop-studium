<%*
let nazev = tp.file.title;
if (/^(Untitled|Bez názvu)/i.test(nazev)) {
  nazev = ((await tp.system.prompt("Název zkoušky (např. Anatomie – zápočtový test)")) || "Zkouška").trim();
}
const zaklad = app.vault.getAbstractFileByPath("02 Studium/Fyzioterapie");
const predmety = (zaklad && zaklad.children ? zaklad.children : [])
  .filter(f => f.children)
  .map(f => f.name)
  .sort((a, b) => a.localeCompare(b, "cs"));
const jiny = "✏️ jiný…";
let predmet = await tp.system.suggester([...predmety, jiny], [...predmety, jiny], false, "Z jakého předmětu?");
if (!predmet || predmet === jiny) {
  predmet = ((await tp.system.prompt("Název předmětu")) || "").trim();
}
const druhy = ["zkouška", "zápočet", "test", "ústní"];
const druh = (await tp.system.suggester(druhy, druhy, false, "Co to je?")) || "zkouška";
let datum = ((await tp.system.prompt("Datum (YYYY-MM-DD)", tp.date.now("YYYY-MM-DD", 7))) || "").trim();
if (!/^\d{4}-\d{2}-\d{2}$/.test(datum)) datum = tp.date.now("YYYY-MM-DD", 7);
let cas = ((await tp.system.prompt("Čas začátku HH:mm (prázdné = celý den)")) || "").trim();
if (/^\d{1,2}:\d{2}$/.test(cas)) { cas = cas.padStart(5, "0"); } else { cas = ""; }
const celyDen = cas === "";
let konec = "";
if (!celyDen) {
  konec = moment(cas, "HH:mm").add(90, "minutes").format("HH:mm");
}
const den = (n) => moment(datum, "YYYY-MM-DD").subtract(n, "days").format("YYYY-MM-DD");
const bezpecny = nazev.replace(/[\\/:*?"<>|#^\[\]]/g, "-");
await tp.file.move("02 Studium/Zkoušky/" + datum + " " + bezpecny);
-%>
---
typ: zkouska
predmet: "<% predmet %>"
druh: <% druh %>
datum: <% datum %>
stav: připravuji
title: "📝 <% nazev %>"
date: <% datum %>
allDay: <% celyDen %>
<% celyDen ? "" : "startTime: " + cas + "\nendTime: " + konec + "\n" %>type: single
---
> [!info] Jak na to
> Doplň rozsah, odškrtávej přípravu podle plánu a po zkoušce vyplň `stav` (např. splněno / opakuji). S pluginem Full Calendar (zdroj: složka `02 Studium/Zkoušky`) se zkouška ukáže i v kalendáři.

# 📝 <% nazev %>
**<% druh %>** · <% predmet %> · <% datum %><% celyDen ? "" : " v " + cas %>

## 📋 Co se zkouší (rozsah)
- <% tp.file.cursor(1) %>

## 📚 Zdroje a notes
**Přednášky z předmětu:**
```dataview
LIST
FROM "02 Studium"
WHERE typ = "prednaska" AND predmet = this.predmet
SORT datum ASC
```

**Zdroje:**
```dataview
LIST
FROM "02 Studium/Fyzioterapie/<% predmet %>/Zdroje"
SORT file.name ASC
```

## ✅ Checklist přípravy
**Plán opakování:**
- [ ] T-14 (<% den(14) %>): projít všechny přednášky, sepsat rozsah a mezery
- [ ] T-7 (<% den(7) %>): první opakování + kartičky
- [ ] T-3 (<% den(3) %>): druhé opakování, zaměřit se na „Co ještě nechápu“
- [ ] T-1 (<% den(1) %>): rychlé zopakování, kartičky, vyspat se 😴

**Další:**
- [ ] Zjistit formu a podmínky (počet otázek, hodnocení)
- [ ] Sehnat materiály / staré otázky
- [ ] 

## ❓ Co ještě nechápu
- [ ] 

## 📝 Po zkoušce
**Co příště jinak:**
- 
