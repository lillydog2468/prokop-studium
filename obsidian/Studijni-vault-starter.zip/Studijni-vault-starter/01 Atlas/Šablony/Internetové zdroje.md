---
typ:
autor:
zdroj:
předmět:
datum_pridani: <% tp.date.now("YYYY-MM-DD") %>
---
# <% tp.file.title %>

## 📌 Shrnutí zdroje
<% tp.file.cursor(1) %>


## 📝 Klíčové informace a výpisky
- 

## 🔗 Související poznámky
-

