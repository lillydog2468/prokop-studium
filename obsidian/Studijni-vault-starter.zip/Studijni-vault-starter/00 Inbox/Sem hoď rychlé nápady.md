# 📥 Inbox
Sem si házej všechno rychle (nápad z přednášky, odkaz, otázku). Jednou týdně to roztřiď do `02 Studium`.
